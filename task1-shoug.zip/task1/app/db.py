import os, sqlite3

DB_PATH = os.getenv("DB_PATH", "./blobs.db")
os.makedirs(os.path.dirname(DB_PATH) or ".", exist_ok=True)

conn = sqlite3.connect(DB_PATH, check_same_thread=False)
conn.execute(
    """CREATE TABLE IF NOT EXISTS blob_meta (
      id TEXT PRIMARY KEY,
      size INTEGER NOT NULL,
      created_at TEXT NOT NULL,
      backend TEXT NOT NULL,
      storage_key TEXT NOT NULL
    )"""
)
conn.execute(
    """CREATE TABLE IF NOT EXISTS blob_data (
      id TEXT PRIMARY KEY,
      data BLOB NOT NULL
    )"""
)
conn.commit()
