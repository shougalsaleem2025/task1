from ftplib import FTP
from io import BytesIO
from .base import Storage

class FTPStorage(Storage):
    def __init__(self, host, port, user, password, base_dir='/'):
        self.host=host; self.port=port; self.user=user; self.password=password; self.base_dir=base_dir or '/'
    def _connect(self):
        ftp = FTP(); ftp.connect(self.host, self.port, timeout=15); ftp.login(self.user, self.password); ftp.cwd(self.base_dir); return ftp
    def put(self, blob_id, data: bytes) -> str:
        key = blob_id
        with self._connect() as ftp: ftp.storbinary(f"STOR {key}", BytesIO(data))
        return key
    def get(self, blob_id, storage_key: str) -> bytes:
        with self._connect() as ftp:
            buf = BytesIO(); ftp.retrbinary(f"RETR {storage_key}", buf.write); return buf.getvalue()
    def delete(self, blob_id, storage_key: str) -> None:
        with self._connect() as ftp:
            try: ftp.delete(storage_key)
            except Exception: pass
