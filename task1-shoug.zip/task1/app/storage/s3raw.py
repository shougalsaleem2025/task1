import hashlib, hmac, requests
from datetime import datetime, timezone
from urllib.parse import urlparse
from .base import Storage

class S3Raw(Storage):
    def __init__(self, endpoint, bucket, region, access_key, secret_key):
        if not all([endpoint,bucket,region,access_key,secret_key]):
            raise RuntimeError('S3 config is incomplete')
        self.endpoint = endpoint.rstrip('/'); self.bucket=bucket; self.region=region
        self.ak=access_key; self.sk=secret_key

    def _headers(self, payload_hash):
        amz_date = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
        host = urlparse(self.endpoint).netloc
        canonical_headers = f"host:{host}\n" + f"x-amz-content-sha256:{payload_hash}\n" + f"x-amz-date:{amz_date}\n"
        signed_headers = "host;x-amz-content-sha256;x-amz-date"
        return amz_date, host, canonical_headers, signed_headers

    def _signing_key(self, date_stamp):
        k = hmac.new(('AWS4'+self.sk).encode(), date_stamp.encode(), 'sha256').digest()
        k = hmac.new(k, self.region.encode(), 'sha256').digest()
        k = hmac.new(k, b's3', 'sha256').digest()
        return hmac.new(k, b'aws4_request', 'sha256').digest()

    def _auth(self, method, url_path, payload_hash, amz_date):
        date_stamp = amz_date[:8]
        _, _, canonical_headers, signed_headers = self._headers(payload_hash)
        can_req = "\n".join([method, url_path, "", canonical_headers, signed_headers, payload_hash])
        scope = f"{date_stamp}/{self.region}/s3/aws4_request"
        sts = "\n".join(["AWS4-HMAC-SHA256", amz_date, scope, hashlib.sha256(can_req.encode()).hexdigest()])
        sig = hmac.new(self._signing_key(date_stamp), sts.encode(), hashlib.sha256).hexdigest()
        return f"AWS4-HMAC-SHA256 Credential={self.ak}/{scope}, SignedHeaders={signed_headers}, Signature={sig}"

    def _path(self, key): return f"/{self.bucket}/{key}"

    def put(self, blob_id, data: bytes) -> str:
        key = blob_id; url_path=self._path(key); url=f"{self.endpoint}{url_path}"
        payload_hash = hashlib.sha256(data).hexdigest()
        amz_date, host, _, _ = self._headers(payload_hash)
        r = requests.put(url, data=data, headers={
            "host": host, "x-amz-date": amz_date, "x-amz-content-sha256": payload_hash,
            "Authorization": self._auth("PUT", url_path, payload_hash, amz_date),
            "Content-Length": str(len(data))
        })
        if r.status_code not in (200,201): raise RuntimeError(f"S3 PUT failed: {r.status_code} {r.text}")
        return key

    def get(self, blob_id, storage_key: str) -> bytes:
        key = storage_key; url_path=self._path(key); url=f"{self.endpoint}{url_path}"
        payload_hash = "UNSIGNED-PAYLOAD"
        amz_date, host, _, _ = self._headers(payload_hash)
        r = requests.get(url, headers={
            "host": host, "x-amz-date": amz_date, "x-amz-content-sha256": payload_hash,
            "Authorization": self._auth("GET", url_path, payload_hash, amz_date),
        })
        if r.status_code!=200: raise RuntimeError(f"S3 GET failed: {r.status_code} {r.text}")
        return r.content

    def delete(self, blob_id, storage_key: str) -> None:
        key = storage_key; url_path=self._path(key); url=f"{self.endpoint}{url_path}"
        payload_hash = "UNSIGNED-PAYLOAD"
        amz_date, host, _, _ = self._headers(payload_hash)
        r = requests.delete(url, headers={
            "host": host, "x-amz-date": amz_date, "x-amz-content-sha256": payload_hash,
            "Authorization": self._auth("DELETE", url_path, payload_hash, amz_date),
        })
        if r.status_code not in (200,204): raise RuntimeError(f"S3 DELETE failed: {r.status_code} {r.text}")
