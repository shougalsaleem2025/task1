from fastapi import HTTPException
from ..db import conn
from .base import Storage

class DBStorage(Storage):
    def put(self, blob_id: str, data: bytes) -> str:
        try:
            conn.execute('INSERT INTO blob_data (id, data) VALUES (?,?)', (blob_id, data))
            conn.commit()
        except Exception as e:
            if 'UNIQUE' in str(e).upper():
                raise HTTPException(status_code=409, detail='Blob already exists')
            raise
        return blob_id
    def get(self, blob_id: str, storage_key: str) -> bytes:
        row = conn.execute('SELECT data FROM blob_data WHERE id=?', (blob_id,)).fetchone()
        if not row: raise HTTPException(status_code=404, detail='Blob not found in DB storage')
        return row[0]
    def delete(self, blob_id: str, storage_key: str) -> None:
        conn.execute('DELETE FROM blob_data WHERE id=?', (blob_id,)); conn.commit()
