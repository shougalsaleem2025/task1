class Storage:
    def put(self, blob_id: str, data: bytes) -> str: raise NotImplementedError
    def get(self, blob_id: str, storage_key: str) -> bytes: raise NotImplementedError
    def delete(self, blob_id: str, storage_key: str) -> None: raise NotImplementedError
