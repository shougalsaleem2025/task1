import os
from urllib.parse import quote
from .base import Storage

class LocalStorage(Storage):
    def __init__(self, base_dir: str):
        self.base = base_dir; os.makedirs(self.base, exist_ok=True)
    def _path(self, blob_id: str) -> str:
        return os.path.join(self.base, quote(blob_id, safe=""))
    def put(self, blob_id: str, data: bytes) -> str:
        p = self._path(blob_id); open(p,"wb").write(data); return p
    def get(self, blob_id: str, storage_key: str) -> bytes:
        return open(storage_key,"rb").read()
    def delete(self, blob_id: str, storage_key: str) -> None:
        try: os.remove(storage_key)
        except FileNotFoundError: pass
