import os, base64
from datetime import datetime, timezone
from fastapi import FastAPI, HTTPException, Depends
from dotenv import load_dotenv

from .models import BlobIn, BlobOut
from .auth import bearer_auth
from .db import conn

from .storage.base import Storage
from .storage.local import LocalStorage
from .storage.dbstore import DBStorage
from .storage.s3raw import S3Raw
from .storage.ftpstore import FTPStorage

load_dotenv()
BACKEND = os.getenv('STORAGE_BACKEND','local').lower()

def get_storage()->Storage:
    if BACKEND=='local': return LocalStorage(os.getenv('LOCAL_DIR','./storage'))
    if BACKEND=='db': return DBStorage()
    if BACKEND=='s3':
        return S3Raw(
            endpoint=os.getenv('S3_ENDPOINT',''),
            bucket=os.getenv('S3_BUCKET',''),
            region=os.getenv('S3_REGION','us-east-1'),
            access_key=os.getenv('S3_ACCESS_KEY',''),
            secret_key=os.getenv('S3_SECRET_KEY',''),
        )
    if BACKEND=='ftp':
        return FTPStorage(
            host=os.getenv('FTP_HOST','127.0.0.1'),
            port=int(os.getenv('FTP_PORT','21')),
            user=os.getenv('FTP_USER','anonymous'),
            password=os.getenv('FTP_PASS',''),
            base_dir=os.getenv('FTP_BASE_DIR','/'),
        )
    raise RuntimeError('Unknown STORAGE_BACKEND')

storage = get_storage()
app = FastAPI(title='Simple Drive', version='1.0.0', swagger_ui_parameters={"persistAuthorization": True})


@app.post('/v1/blobs', dependencies=[Depends(bearer_auth)], response_model=BlobOut)
def create_blob(blob: BlobIn):
    if conn.execute('SELECT 1 FROM blob_meta WHERE id=?',(blob.id,)).fetchone():
        raise HTTPException(status_code=409, detail='Blob already exists')
    raw = base64.b64decode(blob.data, validate=True)
    size = len(raw)
    created_at = datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')
    try: storage_key = storage.put(blob.id, raw)
    except Exception as e: raise HTTPException(status_code=500, detail=f'storage error: {e}')
    conn.execute('INSERT INTO blob_meta (id,size,created_at,backend,storage_key) VALUES (?,?,?,?,?)',
                (blob.id,size,created_at,os.getenv('STORAGE_BACKEND','local'),storage_key))
    conn.commit()
    return BlobOut(id=blob.id, data=blob.data, size=size, created_at=created_at)

@app.get('/v1/blobs/{blob_id}', dependencies=[Depends(bearer_auth)], response_model=BlobOut)
def get_blob(blob_id: str):
    row = conn.execute('SELECT size,created_at,backend,storage_key FROM blob_meta WHERE id=?',(blob_id,)).fetchone()
    if not row: raise HTTPException(status_code=404, detail='Blob not found')
    size, created_at, backend, storage_key = row
    try: data_bytes = storage.get(blob_id, storage_key)
    except Exception as e: raise HTTPException(status_code=500, detail=f'storage error: {e}')
    b64 = base64.b64encode(data_bytes).decode()
    return BlobOut(id=blob_id, data=b64, size=size, created_at=created_at)

@app.get('/v1/blobs', dependencies=[Depends(bearer_auth)])
def list_blobs():
    cur = conn.execute('SELECT id,size,created_at FROM blob_meta ORDER BY created_at DESC')
    rows = [{'id':r[0],'size':r[1],'created_at':r[2]} for r in cur.fetchall()]
    return {'items': rows, 'count': len(rows)}

@app.delete('/v1/blobs/{blob_id}', dependencies=[Depends(bearer_auth)])
def delete_blob(blob_id: str):
    row = conn.execute('SELECT backend,storage_key FROM blob_meta WHERE id=?',(blob_id,)).fetchone()
    if not row: raise HTTPException(status_code=404, detail='Blob not found')
    backend, storage_key = row
    try: storage.delete(blob_id, storage_key)
    except Exception as e: raise HTTPException(status_code=500, detail=f'storage error: {e}')
    conn.execute('DELETE FROM blob_meta WHERE id=?',(blob_id,)); conn.commit()
    return {'status':'deleted','id':blob_id}
