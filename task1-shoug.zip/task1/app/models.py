from pydantic import BaseModel, Field, field_validator
import base64

class BlobIn(BaseModel):
    id: str = Field(..., min_length=1)
    data: str

    @field_validator("data")
    @classmethod
    def validate_b64(cls, v: str):
        base64.b64decode(v, validate=True)
        return v

class BlobOut(BaseModel):
    id: str
    data: str
    size: int
    created_at: str
