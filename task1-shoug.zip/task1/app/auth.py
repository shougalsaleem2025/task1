import os
from fastapi import HTTPException, Security
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

API_TOKEN = os.getenv("API_TOKEN", "mysecrettoken")
bearer_scheme = HTTPBearer(auto_error=False)

def bearer_auth(credentials: HTTPAuthorizationCredentials = Security(bearer_scheme)):
    if not credentials or credentials.scheme.lower() != "bearer":
        raise HTTPException(status_code=401, detail="Unauthorized")
    token = credentials.credentials
    if token != API_TOKEN:
        raise HTTPException(status_code=401, detail="Unauthorized")
