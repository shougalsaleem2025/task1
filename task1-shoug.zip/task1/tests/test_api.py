import os, base64, tempfile
from fastapi.testclient import TestClient

os.environ['API_TOKEN']='testtoken'
os.environ['STORAGE_BACKEND']='local'
tmp = tempfile.mkdtemp()
os.environ['LOCAL_DIR']=tmp

from app.main import app  # noqa
c = TestClient(app)
auth={'Authorization':'Bearer testtoken'}

def test_unauthorized():
    r = c.post('/v1/blobs', json={'id':'x','data':'SGVsbG8='}); assert r.status_code==401

def test_invalid_b64():
    r = c.post('/v1/blobs', headers=auth, json={'id':'x','data':'notb64'}); assert r.status_code==422

def test_create_get_delete():
    b64 = base64.b64encode(b'hello').decode()
    r = c.post('/v1/blobs', headers=auth, json={'id':'unit1','data':b64}); assert r.status_code==200
    r = c.get('/v1/blobs/unit1', headers=auth); assert r.status_code==200
    r = c.get('/v1/blobs', headers=auth); assert r.status_code==200 and r.json()['count']>=1
    r = c.delete('/v1/blobs/unit1', headers=auth); assert r.status_code==200
