# Simple Drive

Small object-storage API (FastAPI). One interface, multiple backends.

## Endpoints
- POST /v1/blobs
- GET /v1/blobs/{id}
- GET /v1/blobs
- DELETE /v1/blobs/{id}

Auth: `Authorization: Bearer <token>`

## Backends
Set `STORAGE_BACKEND` in `.env`: `local` | `db` | `s3` | `ftp`.

## Run
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload

## Tests
PYTHONPATH=. pytest -q
